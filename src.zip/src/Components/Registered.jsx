


function Registered() {



  return (

    <div className="flex">
      Registered
    </div>
  );
}

export default Registered;