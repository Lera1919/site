import Header from '../Components/Header.jsx'

export default function Movies() {
    return (
        <>
        <Header />
        <h1>Movies</h1>
        </>
    );
  }

  