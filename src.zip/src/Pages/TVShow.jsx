import Header from '../Components/Header.jsx'

export default function TVShow() {
    return (
        <>
        <Header />
        <h1>TV Show</h1>
        </>
    );
  }

  