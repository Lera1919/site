import Header from '../Components/Header.jsx'

export default function Contacts() {
    return (
        <>
        <Header />
        <h1>Contacts</h1>
        </>
    );
  }

  